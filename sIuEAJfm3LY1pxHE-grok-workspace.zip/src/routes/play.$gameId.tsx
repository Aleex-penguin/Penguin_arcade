import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { getGame } from "@/lib/games";
import { useEffect } from "react";

export const Route = createFileRoute("/play/$gameId")({
  component: PlayGame,
});

function PlayGame() {
  const { gameId } = Route.useParams();
  const navigate = useNavigate();
  const game = getGame(gameId);

  useEffect(() => {
    if (!game) {
      void navigate({ to: "/" });
    }
  }, [game, navigate]);

  if (!game) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-bg text-phosphor">
        Cartridge not found. Returning.
      </main>
    );
  }

  return (
    <main className="flex h-dvh flex-col bg-chassis">
      <div className="flex items-center justify-between gap-3 border-b border-border-strong bg-bezel px-3 py-2">
        <Link
          to="/"
          className="inline-flex min-h-10 items-center border border-border px-3 text-[11px] tracking-[0.18em] text-phosphor hover:border-phosphor"
        >
          RETURN
        </Link>
        <p className="truncate text-[11px] tracking-[0.2em] text-muted">
          {game.callsign} // {game.title}
        </p>
        <span className="text-[11px] tracking-[0.16em] text-phosphor">LIVE</span>
      </div>
      <iframe
        title={game.title}
        src={game.file}
        className="h-full w-full flex-1 border-0 bg-black"
        allow="autoplay; fullscreen"
      />
    </main>
  );
}
