import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PenguinMark } from "@/components/PenguinMark";
import { GAMES, type GameCartridge } from "@/lib/games";

export const Route = createFileRoute("/")({ component: Home });

const BOOT_LINES = [
  "ALEEX COMMAND OS  v4.07",
  "INITIALIZING TACTICAL ENTERTAINMENT SUITE",
  "OPERATOR IDENTITY ........ ALEEX",
  "MOUNTING GAME CARTRIDGES .. 4 UNITS",
  "PHOSPHOR LINK ............. STABLE",
  "STATION 07 READY.",
];

function readBest(key: string): string {
  if (typeof window === "undefined") return "--";
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return "--";
    const n = Number(raw);
    return Number.isFinite(n) ? String(n) : raw;
  } catch {
    return "--";
  }
}

function Home() {
  const [booting, setBooting] = useState(true);
  const [lineCount, setLineCount] = useState(0);
  const [clock, setClock] = useState("--:--:--");
  const [scores, setScores] = useState<Record<string, string>>({});

  useEffect(() => {
    const tick = () => {
      setClock(
        new Date().toLocaleTimeString("en-GB", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
        }),
      );
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const next: Record<string, string> = {};
    for (const g of GAMES) next[g.id] = readBest(g.scoreKey);
    setScores(next);
  }, []);

  useEffect(() => {
    if (!booting) return;
    if (lineCount >= BOOT_LINES.length) {
      const t = window.setTimeout(() => setBooting(false), 420);
      return () => window.clearTimeout(t);
    }
    const t = window.setTimeout(() => setLineCount((n) => n + 1), 90);
    return () => window.clearTimeout(t);
  }, [booting, lineCount]);

  return (
    <main className="min-h-dvh bg-chassis px-3 py-3 sm:px-5 sm:py-5">
      <div className="mx-auto flex min-h-[calc(100dvh-1.5rem)] max-w-6xl flex-col border border-border-strong bg-bezel p-2 sm:p-3">
        <header className="flex items-center justify-between gap-3 border border-border bg-panel px-3 py-2">
          <p className="text-[10px] tracking-[0.22em] text-muted sm:text-xs">
            UNCLASSIFIED // TRAINING USE ONLY
          </p>
          <p className="text-[10px] tracking-[0.18em] text-phosphor sm:text-xs">
            STATION 07
          </p>
        </header>

        <div className="relative mt-2 flex min-h-0 flex-1 flex-col overflow-hidden border border-border bg-bg">
          <div className="scanlines absolute inset-0 z-10 opacity-70" />
          <div className="crt-flicker relative z-20 flex min-h-0 flex-1 flex-col p-3 sm:p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <PenguinMark className="h-12 w-10 text-phosphor sm:h-14 sm:w-12" />
                <div>
                  <p className="text-[10px] tracking-[0.28em] text-muted">
                    ALEEX COMMAND
                  </p>
                  <h1 className="phosphor-glow text-xl leading-tight tracking-wide text-phosphor sm:text-3xl">
                    ALEEX'S PENGUIN ARCADE
                  </h1>
                  <p className="mt-1 text-[11px] tracking-[0.16em] text-muted">
                    FIELD COMPUTER // GAME CARTRIDGE BAY
                  </p>
                </div>
              </div>
              <div className="hidden text-right sm:block">
                <p className="text-[10px] tracking-[0.2em] text-muted">SYS TIME</p>
                <p className="font-mono text-lg tabular-nums text-phosphor">{clock}</p>
              </div>
            </div>

            {booting ? (
              <BootPanel lines={BOOT_LINES.slice(0, lineCount)} />
            ) : (
              <section className="mt-5 grid min-h-0 flex-1 gap-4 lg:grid-cols-[220px_minmax(0,1fr)]">
                <aside className="h-fit border border-border bg-panel p-3">
                  <p className="text-[10px] tracking-[0.24em] text-muted">SYSTEM</p>
                  <ul className="mt-3 space-y-2 text-xs tracking-wide">
                    <StatusRow label="LINK" value="ONLINE" ok />
                    <StatusRow label="CARTS" value={`${GAMES.length} LOADED`} ok />
                    <StatusRow label="OPERATOR" value="ALEEX" ok />
                    <StatusRow label="CLOCK" value={clock} ok />
                  </ul>
                  <p className="mt-5 text-[10px] tracking-[0.24em] text-muted">
                    BRIEF
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-fg">
                    Select a cartridge and press LOAD. All titles run in this
                    terminal. Best scores persist on this station.
                  </p>
                </aside>

                <div className="grid content-start gap-3 sm:grid-cols-2">
                  {GAMES.map((game) => (
                    <GameCard
                      key={game.id}
                      game={game}
                      best={scores[game.id] ?? "--"}
                    />
                  ))}
                </div>
              </section>
            )}
          </div>
        </div>

        <footer className="mt-2 flex flex-wrap items-center justify-between gap-2 border border-border bg-panel px-3 py-2 text-[10px] tracking-[0.16em] text-muted">
          <span>PWR STABLE</span>
          <span className="text-phosphor">PHOSPHOR NOMINAL</span>
          <span>RETROFIT OS 4.07</span>
        </footer>
      </div>
    </main>
  );
}

function BootPanel({ lines }: { lines: string[] }) {
  return (
    <div className="mt-8 max-w-xl space-y-2 text-sm tracking-wide text-phosphor">
      {lines.map((line) => (
        <p key={line}>{"> "}{line}</p>
      ))}
      <p className="animate-pulse">{">"}_</p>
    </div>
  );
}

function StatusRow({
  label,
  value,
  ok,
}: {
  label: string;
  value: string;
  ok: boolean;
}) {
  return (
    <li className="flex items-center justify-between gap-2">
      <span className="text-muted">{label}</span>
      <span className={ok ? "text-phosphor" : "text-alert"}>{value}</span>
    </li>
  );
}

function GameCard({ game, best }: { game: GameCartridge; best: string }) {
  return (
    <article className="flex flex-col border border-border bg-panel p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[10px] tracking-[0.22em] text-muted">{game.callsign}</p>
        <p className="text-[10px] tracking-[0.18em] text-phosphor">{game.clearance}</p>
      </div>
      <h2 className="mt-2 text-lg tracking-wide text-phosphor">{game.title}</h2>
      <p className="text-[11px] tracking-[0.14em] text-muted">{game.genre}</p>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-fg">{game.summary}</p>
      <div className="mt-4 flex items-end justify-between gap-3">
        <p className="text-[11px] tracking-wide text-muted">
          BEST <span className="tabular-nums text-phosphor">{best}</span>
        </p>
        <Link
          to="/play/$gameId"
          params={{ gameId: game.id }}
          className="inline-flex min-h-11 items-center border border-phosphor px-4 text-xs tracking-[0.2em] text-phosphor hover:bg-phosphor hover:text-bg"
        >
          LOAD
        </Link>
      </div>
    </article>
  );
}
