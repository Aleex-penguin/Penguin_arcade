export type GameCartridge = {
  id: string;
  callsign: string;
  title: string;
  genre: string;
  clearance: "UNCLASS" | "RESTRICTED" | "SECRET";
  file: string;
  summary: string;
  scoreKey: string;
};

export const GAMES: GameCartridge[] = [
  {
    id: "delta-ops",
    callsign: "D-OPS",
    title: "DELTA OPS",
    genre: "TACTICAL FPS",
    clearance: "SECRET",
    file: "/games/delta-ops.html",
    summary:
      "Urban, desert, arctic, and farmland maps. Operator upgrades, ADS optics, and live fire against hostile patrols.",
    scoreKey: "deltaOpsHighScore",
  },
  {
    id: "ice-range",
    callsign: "I-RNG",
    title: "ICE RANGE",
    genre: "MARKSMAN",
    clearance: "UNCLASS",
    file: "/games/ice-range.html",
    summary:
      "Live-fire qualification on a frozen range. Track drifting plates, manage ammo, and post a clean score.",
    scoreKey: "penguinArcade.ice-range",
  },
  {
    id: "ice-recon",
    callsign: "I-REC",
    title: "ICE RECON",
    genre: "GRID INTEL",
    clearance: "RESTRICTED",
    file: "/games/ice-recon.html",
    summary:
      "Sweep a frozen minefield. Mark buried charges, read adjacent intel, and extract without a blast.",
    scoreKey: "penguinArcade.ice-recon",
  },
  {
    id: "frost-convoy",
    callsign: "F-CNV",
    title: "FROST CONVOY",
    genre: "SUPPLY RUN",
    clearance: "UNCLASS",
    file: "/games/frost-convoy.html",
    summary:
      "Keep the ice-road convoy moving. Shift lanes, dodge wreckage, and deliver the payload.",
    scoreKey: "penguinArcade.frost-convoy",
  },
];

export function getGame(id: string) {
  return GAMES.find((g) => g.id === id);
}
