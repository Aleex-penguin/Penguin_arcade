export function PenguinMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 56"
      className={className}
      aria-hidden="true"
      fill="currentColor"
    >
      <ellipse cx="24" cy="34" rx="16" ry="18" />
      <circle cx="24" cy="14" r="10" />
      <ellipse cx="24" cy="38" rx="9" ry="12" fill="#070a07" />
      <circle cx="20" cy="12" r="1.6" fill="#070a07" />
      <circle cx="28" cy="12" r="1.6" fill="#070a07" />
      <path d="M24 15 L30 18 L24 20 Z" fill="#070a07" />
      <path d="M10 34 L4 38 L10 40 Z" />
      <path d="M38 34 L44 38 L38 40 Z" />
      <path d="M16 50 L20 54 L24 50 L28 54 L32 50" />
    </svg>
  );
}
