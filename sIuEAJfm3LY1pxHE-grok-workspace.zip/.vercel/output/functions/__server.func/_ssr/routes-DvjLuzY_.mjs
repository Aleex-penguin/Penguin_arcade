import { i as __toESM } from "../_runtime.mjs";
import { _ as Link, b as require_jsx_runtime, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as GAMES } from "./games-ByM6BmXx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DvjLuzY_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PenguinMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 56",
		className,
		"aria-hidden": "true",
		fill: "currentColor",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "24",
				cy: "34",
				rx: "16",
				ry: "18"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "14",
				r: "10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "24",
				cy: "38",
				rx: "9",
				ry: "12",
				fill: "#070a07"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20",
				cy: "12",
				r: "1.6",
				fill: "#070a07"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "28",
				cy: "12",
				r: "1.6",
				fill: "#070a07"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 15 L30 18 L24 20 Z",
				fill: "#070a07"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 34 L4 38 L10 40 Z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M38 34 L44 38 L38 40 Z" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 50 L20 54 L24 50 L28 54 L32 50" })
		]
	});
}
var BOOT_LINES = [
	"ALEEX COMMAND OS  v4.07",
	"INITIALIZING TACTICAL ENTERTAINMENT SUITE",
	"OPERATOR IDENTITY ........ ALEEX",
	"MOUNTING GAME CARTRIDGES .. 4 UNITS",
	"PHOSPHOR LINK ............. STABLE",
	"STATION 07 READY."
];
function readBest(key) {
	if (typeof window === "undefined") return "--";
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return "--";
		const n = Number(raw);
		return Number.isFinite(n) ? String(n) : raw;
	} catch {
		return "--";
	}
}
function Home() {
	const [booting, setBooting] = (0, import_react.useState)(true);
	const [lineCount, setLineCount] = (0, import_react.useState)(0);
	const [clock, setClock] = (0, import_react.useState)("--:--:--");
	const [scores, setScores] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		const tick = () => {
			setClock((/* @__PURE__ */ new Date()).toLocaleTimeString("en-GB", {
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit",
				hour12: false
			}));
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		const next = {};
		for (const g of GAMES) next[g.id] = readBest(g.scoreKey);
		setScores(next);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!booting) return;
		if (lineCount >= BOOT_LINES.length) {
			const t = window.setTimeout(() => setBooting(false), 420);
			return () => window.clearTimeout(t);
		}
		const t = window.setTimeout(() => setLineCount((n) => n + 1), 90);
		return () => window.clearTimeout(t);
	}, [booting, lineCount]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-dvh bg-chassis px-3 py-3 sm:px-5 sm:py-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-[calc(100dvh-1.5rem)] max-w-6xl flex-col border border-border-strong bg-bezel p-2 sm:p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 border border-border bg-panel px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] tracking-[0.22em] text-muted sm:text-xs",
						children: "UNCLASSIFIED // TRAINING USE ONLY"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] tracking-[0.18em] text-phosphor sm:text-xs",
						children: "STATION 07"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-2 flex min-h-0 flex-1 flex-col overflow-hidden border border-border bg-bg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scanlines absolute inset-0 z-10 opacity-70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "crt-flicker relative z-20 flex min-h-0 flex-1 flex-col p-3 sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenguinMark, { className: "h-12 w-10 text-phosphor sm:h-14 sm:w-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] tracking-[0.28em] text-muted",
										children: "ALEEX COMMAND"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "phosphor-glow text-xl leading-tight tracking-wide text-phosphor sm:text-3xl",
										children: "ALEEX'S PENGUIN ARCADE"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-[11px] tracking-[0.16em] text-muted",
										children: "FIELD COMPUTER // GAME CARTRIDGE BAY"
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden text-right sm:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] tracking-[0.2em] text-muted",
									children: "SYS TIME"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-lg tabular-nums text-phosphor",
									children: clock
								})]
							})]
						}), booting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootPanel, { lines: BOOT_LINES.slice(0, lineCount) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-5 grid min-h-0 flex-1 gap-4 lg:grid-cols-[220px_minmax(0,1fr)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
								className: "h-fit border border-border bg-panel p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] tracking-[0.24em] text-muted",
										children: "SYSTEM"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
										className: "mt-3 space-y-2 text-xs tracking-wide",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusRow, {
												label: "LINK",
												value: "ONLINE",
												ok: true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusRow, {
												label: "CARTS",
												value: `${GAMES.length} LOADED`,
												ok: true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusRow, {
												label: "OPERATOR",
												value: "ALEEX",
												ok: true
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusRow, {
												label: "CLOCK",
												value: clock,
												ok: true
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 text-[10px] tracking-[0.24em] text-muted",
										children: "BRIEF"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-fg",
										children: "Select a cartridge and press LOAD. All titles run in this terminal. Best scores persist on this station."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid content-start gap-3 sm:grid-cols-2",
								children: GAMES.map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameCard, {
									game,
									best: scores[game.id] ?? "--"
								}, game.id))
							})]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-2 flex flex-wrap items-center justify-between gap-2 border border-border bg-panel px-3 py-2 text-[10px] tracking-[0.16em] text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "PWR STABLE" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-phosphor",
							children: "PHOSPHOR NOMINAL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "RETROFIT OS 4.07" })
					]
				})
			]
		})
	});
}
function BootPanel({ lines }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 max-w-xl space-y-2 text-sm tracking-wide text-phosphor",
		children: [lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["> ", line] }, line)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "animate-pulse",
			children: [">", "_"]
		})]
	});
}
function StatusRow({ label, value, ok }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: ok ? "text-phosphor" : "text-alert",
			children: value
		})]
	});
}
function GameCard({ game, best }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col border border-border bg-panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] tracking-[0.22em] text-muted",
					children: game.callsign
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] tracking-[0.18em] text-phosphor",
					children: game.clearance
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-lg tracking-wide text-phosphor",
				children: game.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] tracking-[0.14em] text-muted",
				children: game.genre
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 flex-1 text-sm leading-relaxed text-fg",
				children: game.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] tracking-wide text-muted",
					children: ["BEST ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-phosphor",
						children: best
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/play/$gameId",
					params: { gameId: game.id },
					className: "inline-flex min-h-11 items-center border border-phosphor px-4 text-xs tracking-[0.2em] text-phosphor hover:bg-phosphor hover:text-bg",
					children: "LOAD"
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
