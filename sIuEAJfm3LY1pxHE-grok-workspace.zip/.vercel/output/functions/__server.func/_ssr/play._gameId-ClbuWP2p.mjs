import { i as __toESM } from "../_runtime.mjs";
import { _ as Link, b as require_jsx_runtime, v as useNavigate, z as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-BdYWP7Jd.mjs";
import { n as getGame } from "./games-ByM6BmXx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/play._gameId-ClbuWP2p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PlayGame() {
	const { gameId } = Route.useParams();
	const navigate = useNavigate();
	const game = getGame(gameId);
	(0, import_react.useEffect)(() => {
		if (!game) navigate({ to: "/" });
	}, [game, navigate]);
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-phosphor",
		children: "Cartridge not found. Returning."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh flex-col bg-chassis",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-border-strong bg-bezel px-3 py-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex min-h-10 items-center border border-border px-3 text-[11px] tracking-[0.18em] text-phosphor hover:border-phosphor",
					children: "RETURN"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-[11px] tracking-[0.2em] text-muted",
					children: [
						game.callsign,
						" // ",
						game.title
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] tracking-[0.16em] text-phosphor",
					children: "LIVE"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			title: game.title,
			src: game.file,
			className: "h-full w-full flex-1 border-0 bg-black",
			allow: "autoplay; fullscreen"
		})]
	});
}
//#endregion
export { PlayGame as component };
