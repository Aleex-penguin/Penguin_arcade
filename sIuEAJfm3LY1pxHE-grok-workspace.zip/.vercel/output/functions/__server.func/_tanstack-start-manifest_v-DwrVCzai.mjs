//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DwrVCzai.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/play/$gameId"],
		preloads: ["/assets/index-DeAwAJ6d.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DeAwAJ6d.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DvQ7WGE_.js", "/assets/games-Df7dFbV6.js"]
	},
	"/play/$gameId": {
		filePath: "/workspace/src/routes/play.$gameId.tsx",
		children: void 0,
		preloads: ["/assets/play._gameId-DWjxcrFh.js", "/assets/games-Df7dFbV6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
